package time;

import java.util.ArrayList;

public class Question {

	private String Ques = "";
	
	private ArrayList<String> choices = new ArrayList<String>(4);

	public String getQues() {
		return Ques;
	}

	public void setQues(String ques) {
		Ques = ques;
	}

	public ArrayList<String> getChoices() {
		return choices;
	}

	public void setChoices(ArrayList<String> choices) {
		this.choices = choices;
	} 

	public void addChoices(String choice) {
		this.choices.add(choice);
	} 
	
	
}
