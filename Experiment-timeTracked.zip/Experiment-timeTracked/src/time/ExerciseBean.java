package time;

import java.util.ArrayList;

public class ExerciseBean {

	private int fileIdentifier = 0;
	
	private ArrayList<String> essay_parts = new ArrayList<String>();
	
	private ArrayList<Question> questions = new ArrayList<Question>();

	public ArrayList<String> getEssay_parts() {
		return essay_parts;
	}

	public void setEssay_parts(ArrayList<String> essay_parts) {
		this.essay_parts = essay_parts;
	}

	public ArrayList<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(ArrayList<Question> questions) {
		this.questions = questions;
	}

	public int getFileIdentifier() {
		return fileIdentifier;
	}

	public void setFileIdentifier(int fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	
	
}
