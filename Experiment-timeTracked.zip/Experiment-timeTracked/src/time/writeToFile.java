package time;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class writeToFile
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/writeToFile" })
public class writeToFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public writeToFile() {
        super();
  
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String to_write= "time "  + request.getParameter("time") + "\t" + " task performed 1 " + request.getParameter("task1").trim() + "\t " + 
		 " task performed 2 " + request.getParameter("task2");
		
		String user_id = request.getParameter("user_id");
		
		String filename = "results_file_path" + request.getParameter("file_answered") + ".txt";
		
		writeittofile(to_write, filename, user_id);
	}

	public void writeittofile(String to_write, String filename, String user_id) {
		try {
			
			
		FileWriter fw = new FileWriter(filename, true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write(to_write + " user_id " + user_id);
		bw.write("\n");
		
			bw.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
