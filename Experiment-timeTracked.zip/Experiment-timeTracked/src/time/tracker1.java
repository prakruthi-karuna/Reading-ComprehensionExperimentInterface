package time;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

/**
 * Servlet implementation class tracker1
 */
@WebServlet("/tracker1")
public class tracker1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public tracker1() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getParameter("q"));
		
		ArrayList<Integer> question_id = new ArrayList<Integer>();
		
		String q = request.getParameter("q");
		String user_id = request.getParameter("n");
		String [] qs = q.split(",");
		for (String s: qs) {
			question_id.add(Integer.parseInt(s));
		}
		
		ArrayList<ExerciseBean> ebs = new ArrayList<ExerciseBean>();
		ExerciseBean eb = new ExerciseBean();
		ArrayList<Question> questions = new ArrayList<Question>();
		
		for (int i: question_id) {
			ExerciseBean ebb = new ExerciseBean();
			ebs.add(ebb);
			ebb.setFileIdentifier(i);
			//Read the file and populate essay and questions
			String question_filename = "questions_file_i.txt"; 
			
			try (BufferedReader br = new BufferedReader(new FileReader(question_filename)))
			{
				
				Question qu = new Question();
				String line = br.readLine();
				while(line != null ) {
					if (!line.isEmpty()) {
					if (line.toLowerCase().contains("question")) {
						 qu = new Question();
						 qu.setQues(line);
						questions.add(qu);
						
					}
					else {
						qu.addChoices(line);
					}
					}
					
					line = br.readLine();
					
					
				}
				
			}
			
			ebb.setQuestions(questions);
			String essay_filename = "essays_file_i.txt"; 
			
		
			try (BufferedReader br = new BufferedReader(new FileReader(essay_filename)))
			{
				String line = br.readLine();
				line = new String(line.getBytes("UTF-8"), "UTF-8");
				String text = "";
				text = text + line + "<br />";
				boolean fresh = false;
				while(line != null ) {
					text = text.replaceAll("\"", "\'");
					if (StringUtils.countMatches(text," ")>=200) {
						String es_part = text;
						ebb.getEssay_parts().add(es_part);
						es_part = "";
						text ="";
						fresh = true;
					}
					
					
					line = br.readLine();
					
					if (line !=null) {
						line = new String(line.getBytes("UTF-8"), "UTF-8");
					text = text + line + "<br />";
					}
					fresh = false;
				}
				
				if (text.length()>0 && fresh==false ) {
					String es_part = text;
					ebb.getEssay_parts().add(es_part);
					
				}
			}
		}
		
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/Exercise.jsp");
		
		
		request.setAttribute("data", ebs);
		request.setAttribute("user_id", user_id);
		
		writeToFile wf = new writeToFile();
		String to_write = "Page load " + System.currentTimeMillis();
		String filename = "results_file_i.txt"; // results are tracked based on question and essay file names
		
		
		
		wf.writeittofile(to_write, filename, user_id);
		
		rd.forward(request, response);
		
		
	}

}
